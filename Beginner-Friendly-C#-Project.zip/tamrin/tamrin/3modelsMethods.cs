﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class modelsMethods
{

    public void PrintTeachersAndEnrollmentsEager()
    {

        SchoolContext schoolContext = new SchoolContext();
        var result = schoolContext.Teachers.Include(x => x.Courses).ThenInclude(c=>c.Enrollments).ToList();

        foreach (var teacher in result)
        {
            Console.WriteLine($"Teacher: {teacher.FirstName}");

            foreach (var enrollments in teacher.Courses)
            {
                Console.WriteLine($"enrollments: \t\t {enrollments.Title}");
            }
        }
        Console.WriteLine("".PadLeft(50, '*'));
    }

    public void PrintTeachersAndCoursesExplicit()
    {

        SchoolContext schoolContext = new SchoolContext();

        var result = schoolContext.Teachers.ToList();
        foreach (var teachers in result)
        {
            Console.WriteLine($"teacher: {teachers.FirstName}");

            if (DateTime.Now.Hour == 10)
            {
                schoolContext.Entry(teachers).Collection(c => c.Courses).Load();

                foreach (var teachersCourses in teachers.Courses)
                {
                    Console.WriteLine($"\t\t course title: {teachersCourses.Title},teacher name:  {teachersCourses.Teacher.FirstName}");
                }
            }
        }
        Console.WriteLine("".PadLeft(50, '*'));
    }

    public void PrintOrderdCourses()
    {
        SchoolContext schoolContext = new SchoolContext();

        var result = schoolContext.Courses.OrderByDescending(c=>c.CourseId).ToList();
        foreach (var items in result)
        {
            Console.WriteLine($"courseId: {items.CourseId},title: {items.Title}");
        }

        Console.WriteLine("".PadLeft(50, '*'));


    }

    public void PrintStudentsLike()
    {
        SchoolContext schoolContext = new SchoolContext();
        var result = schoolContext.Students.Where(c => EF.Functions.Like(c.FirstName, "%ame3")).ToList();
        foreach (var item in result)
        {
            Console.WriteLine($"std id: {item.StudentId}, name: {item.FirstName}");
        }
        Console.WriteLine("".PadLeft(50, '*'));

    }

    public void Paging()
    {
        SchoolContext schoolContext = new SchoolContext();
        var result = schoolContext.Courses.Skip(1).Take(2).ToList();
        foreach (var item in result)
        {
            Console.WriteLine($"cours id: {item.CourseId}, title: {item.Title}");
        }

        Console.WriteLine("".PadLeft(50, '*'));


    }



}

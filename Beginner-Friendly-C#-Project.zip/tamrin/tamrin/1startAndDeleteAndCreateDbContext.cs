﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

public class startAndDeleteAndCreateDbContext
{

    //the first thing to do 
    public startAndDeleteAndCreateDbContext() { }

    public void firstActionOfSystem()
    {

        //create DbContext
        SchoolContext schoolContext = new SchoolContext();

        //remove all elements and save changes
        if (schoolContext.Enrollments != null)
        {
            schoolContext.Enrollments.RemoveRange(schoolContext.Enrollments);
            schoolContext.SaveChanges();
        }
        if (schoolContext.Courses != null)
        {
            schoolContext.Courses.RemoveRange(schoolContext.Courses);
            schoolContext.SaveChanges();
        }
        if (schoolContext.Students != null)
        {
            schoolContext.Students.RemoveRange(schoolContext.Students);
            schoolContext.SaveChanges();
        }
        if (schoolContext.Teachers != null)
        {
            schoolContext.Teachers.RemoveRange(schoolContext.Teachers);
            schoolContext.SaveChanges();
        }


        //create new data and put in database
        var student1 = new Student { FirstName = "SFirstName1", LastName = "SLastName1" };
        schoolContext.Students.Add(student1);
        schoolContext.SaveChanges();
        var student2 = new Student { FirstName = "SFirstName2", LastName = "SLastName2" };
        schoolContext.Students.Add(student2);
        schoolContext.SaveChanges();
        var student3 = new Student { FirstName = "SFirstName3", LastName = "SLastName3" };
        schoolContext.Students.Add(student3);
        schoolContext.SaveChanges();
        var student4 = new Student { FirstName = "SFirstName4", LastName = "SLastName4" };
        schoolContext.Students.Add(student4);
        schoolContext.SaveChanges();


        var teacher1 = new Teacher { FirstName = "TFirstName1", LastName = "TLastName1" };
        schoolContext.Teachers.Add(teacher1);
        schoolContext.SaveChanges();
        var teacher2 = new Teacher { FirstName = "TFirstName2", LastName = "TLastName2" };
        schoolContext.Teachers.Add(teacher2);
        schoolContext.SaveChanges();
        var teacher3 = new Teacher { FirstName = "TFirstName3", LastName = "TLastName3" };
        schoolContext.Teachers.Add(teacher3);
        schoolContext.SaveChanges();
        var teacher4 = new Teacher { FirstName = "TFirstName4", LastName = "TLastName4" };
        schoolContext.Teachers.Add(teacher4);
        schoolContext.SaveChanges();


        var course1 = new Course { Title = "course1", TeacherId = teacher1.TeacherId };
        schoolContext.Courses.Add(course1);
        schoolContext.SaveChanges();
        var course2 = new Course { Title = "course2", TeacherId = teacher2.TeacherId };
        schoolContext.Courses.Add(course2);
        schoolContext.SaveChanges();
        var course3 = new Course { Title = "course3", TeacherId = teacher3.TeacherId };
        schoolContext.Courses.Add(course3);
        schoolContext.SaveChanges();
        var course4 = new Course { Title = "course4", TeacherId = teacher4.TeacherId };
        schoolContext.Courses.Add(course4);
        schoolContext.SaveChanges();


        var enrollment1 = new Enrollment { StudentId = student1.StudentId, CourseId = course1.CourseId };
        schoolContext.Enrollments.Add(enrollment1);
        schoolContext.SaveChanges();
        var enrollment2 = new Enrollment { StudentId = student2.StudentId, CourseId = course2.CourseId };
        schoolContext.Enrollments.Add(enrollment2);
        schoolContext.SaveChanges();
        var enrollment3 = new Enrollment { StudentId = student3.StudentId, CourseId = course3.CourseId };
        schoolContext.Enrollments.Add(enrollment3);
        schoolContext.SaveChanges();
        var enrollment4 = new Enrollment { StudentId = student4.StudentId, CourseId = course4.CourseId };
        schoolContext.Enrollments.Add(enrollment4);
        schoolContext.SaveChanges();

    }
}


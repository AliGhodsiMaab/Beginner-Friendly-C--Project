﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class methodsOfStudent
{


    public void AddStd(string FirstName, string LastName)
    {
        Student student = new()
        {
            FirstName = FirstName,
            LastName = LastName
        };
        var schoolContext = new SchoolContext();
        schoolContext.Students.Add(student);
        schoolContext.SaveChanges();
      
    }

    public void PrintStdName(int inputId)
    {
        var schoolContext = new SchoolContext();
        Student student = schoolContext.Students.Find(inputId);

        if (student != null)
        {
            Console.WriteLine($"{student.FirstName} , {student.LastName}");

        }

    }

    public void UpdateStd(int id, string firstName, string lastName)
    {
        var schoolContext = new SchoolContext();
        Student student = schoolContext.Students.Find(id);
        if (student != null)
        {
            student.FirstName = firstName;
            student.LastName = lastName;
            schoolContext.SaveChanges();
        }
    }

    public void deleteStd (int inputId)
    {
        var schoolContext = new SchoolContext();
        if (schoolContext.Students.Any(s => s.StudentId == inputId))
        {

            Student st = schoolContext.Students.Find(inputId);
            schoolContext.Students.Remove(st);
            schoolContext.SaveChanges();
        }

    }

}


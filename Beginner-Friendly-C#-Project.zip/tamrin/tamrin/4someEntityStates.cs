﻿using Azure;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



public class entityStates
{
    public void printDifferentStatesOfEntity()
    {

        SchoolContext SchoolContext = new SchoolContext();
        //-------------------------------------

        Console.WriteLine($"for Detached State: ");

        Teacher teacher = new Teacher();

        var teacherState = SchoolContext.Entry(teacher).State;

        Console.WriteLine($"New teacher object state is: {teacherState}");

        Console.WriteLine("".PadLeft(50, '*'));
        //-------------------------------------
        Console.WriteLine($"for Added State: ");

        SchoolContext.Add(teacher);
        teacherState = SchoolContext.Entry(teacher).State;
        Console.WriteLine($"New teacher object state is: {teacherState}");
        Console.WriteLine("".PadLeft(50, '*'));
        //-------------------------------------
        Console.WriteLine($"for Deleted State: ");

        Teacher teacher2 = new Teacher();
        teacher2.TeacherId = 1;

        SchoolContext.Remove(teacher2);
        teacherState = SchoolContext.Entry(teacher2).State;
        Console.WriteLine($"New teacher object state is: {teacherState}");
        Console.WriteLine("".PadLeft(50, '*'));
        //-------------------------------------

    }
}
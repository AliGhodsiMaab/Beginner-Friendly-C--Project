﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



//for setting of data base at the beginning of running
startAndDeleteAndCreateDbContext startAndDeleteAndCreateDbContext = new startAndDeleteAndCreateDbContext();
startAndDeleteAndCreateDbContext.firstActionOfSystem();

//student class functions
methodsOfStudent methodsOfStudent=new methodsOfStudent();
methodsOfStudent.AddStd("std5FirstName", "std5FirstName");
methodsOfStudent.PrintStdName(1);
methodsOfStudent.UpdateStd(2, "newFirstNameST2", "newLastNameST2");
methodsOfStudent.deleteStd(1);


//for query
modelsMethods modelsMethods = new modelsMethods();
//Eager
modelsMethods.PrintTeachersAndEnrollmentsEager();
//Explicit
modelsMethods.PrintTeachersAndCoursesExplicit();
//PrintOrderd
modelsMethods.PrintOrderdCourses();
//PrintStudentsLike
modelsMethods.PrintStudentsLike();
//Paging
modelsMethods.Paging();


//entity states
entityStates entityStates=new entityStates();
entityStates.printDifferentStatesOfEntity();





